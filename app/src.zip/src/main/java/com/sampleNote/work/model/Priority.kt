package com.sampleNote.work.model

enum class Priority {
    LOW,
    MEDIUM,
    HIGH
}
