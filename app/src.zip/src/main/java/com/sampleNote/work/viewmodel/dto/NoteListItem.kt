package com.sampleNote.work.viewmodel.dto

class NoteListItem(
        val noteId: Long,
        val text: String,
        var color: String
)