package com.sampleNote.work

import android.app.Activity
import android.app.Application
import com.jakewharton.threetenabp.AndroidThreeTen
import com.sampleNote.work.di.DaggerAppComponent
import com.sampleNote.work.di.modules.AppModule
import com.squareup.leakcanary.LeakCanary
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasActivityInjector
import javax.inject.Inject

class FinitoApp : Application(), HasActivityInjector {

    @Inject
    lateinit var mDispatchingAndroidInjector: DispatchingAndroidInjector<Activity>

    override fun activityInjector(): AndroidInjector<Activity> {
        return mDispatchingAndroidInjector
    }

    override fun onCreate() {
        super.onCreate()

        AndroidThreeTen.init(this)

        if (LeakCanary.isInAnalyzerProcess(this)) {
            return;
        }
        LeakCanary.install(this);

        DaggerAppComponent.builder()
                .app(this)
                .applicationModule(AppModule(this))
                .build()
                .inject(this)
    }
}